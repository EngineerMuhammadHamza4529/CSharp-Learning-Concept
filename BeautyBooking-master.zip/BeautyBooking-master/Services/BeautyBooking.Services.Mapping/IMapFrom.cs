﻿namespace BeautyBooking.Services.Mapping
{
    // ReSharper disable once UnusedTypeParameter
    public interface IMapFrom<T>
    {
    }
}
