﻿namespace BeautyBooking.Web.ViewModels.Common.Pagination
{
    public static class PageSizesConstants
    {
        public const int Salons = 8;

        public const int BlogPosts = 1;
    }
}
