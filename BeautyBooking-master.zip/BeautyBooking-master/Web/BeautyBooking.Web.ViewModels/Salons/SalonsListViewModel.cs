﻿namespace BeautyBooking.Web.ViewModels.Salons
{
    using System.Collections.Generic;

    public class SalonsListViewModel
    {
        public IEnumerable<SalonViewModel> Salons { get; set; }
    }
}
