﻿namespace BeautyBooking.Web.ViewModels.Salons
{
    using System.Collections.Generic;

    public class SalonsSimpleListViewModel
    {
        public IEnumerable<SalonSimpleViewModel> Salons { get; set; }
    }
}
