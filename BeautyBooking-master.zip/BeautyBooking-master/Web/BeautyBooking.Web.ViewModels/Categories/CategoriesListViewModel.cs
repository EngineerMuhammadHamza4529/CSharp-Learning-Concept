﻿namespace BeautyBooking.Web.ViewModels.Categories
{
    using System.Collections.Generic;

    public class CategoriesListViewModel
    {
        public IEnumerable<CategoryViewModel> Categories { get; set; }
    }
}
