﻿namespace BeautyBooking.Web.ViewModels.Categories
{
    using System.Collections.Generic;

    public class CategoriesSimpleListViewModel
    {
        public IEnumerable<CategorySimpleViewModel> Categories { get; set; }
    }
}
