﻿namespace BeautyBooking.Web.ViewModels.Services
{
    using System.Collections.Generic;

    public class ServicesListViewModel
    {
        public IEnumerable<ServiceViewModel> Services { get; set; }
    }
}
