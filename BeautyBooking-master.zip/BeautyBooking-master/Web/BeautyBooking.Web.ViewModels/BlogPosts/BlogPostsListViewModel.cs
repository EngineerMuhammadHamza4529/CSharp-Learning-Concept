﻿namespace BeautyBooking.Web.ViewModels.BlogPosts
{
    using System.Collections.Generic;

    public class BlogPostsListViewModel
    {
        public IEnumerable<BlogPostViewModel> BlogPosts { get; set; }
    }
}
